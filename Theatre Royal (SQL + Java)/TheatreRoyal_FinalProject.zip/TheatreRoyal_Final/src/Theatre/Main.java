package Theatre;

public class Main {

	public static void main(String[] args) {
		
		TheatreRoyal tr = new TheatreRoyal();
		tr.start();
		tr.search();
		tr.sell();
		System.out.println("Hello");
	}
}
